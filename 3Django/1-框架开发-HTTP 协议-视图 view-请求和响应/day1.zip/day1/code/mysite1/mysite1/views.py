

from django.http import HttpResponse

def page_view(request):
    html = ''
    if request.method == 'GET':
        dic = dict(request.GET)
        s = str(dic)
        html += "GET请求：" + s
        # b = request.GET['b']
        b = request.GET.get('b', '没有值！！！')
        a = request.GET.getlist('a')
        html += "<br> b=" + b
        html += '<br> a=' + str(a)
    elif request.method == 'POST':
        pass

    return HttpResponse(html)

def show_info_view(request):
    html = "request.path=" + request.path
    if request.method == 'GET':
        html += "<h6>您正在进行GET请求</h6>"
    elif request.method == 'POST':
        html += "<h6>您正在进行POST请求</h6>"
    html += "<h6> 您的IP地址是：" + request.META['REMOTE_ADDR']
    # html += "META=" + str(request.META)
    return HttpResponse(html)


def page1_view(request):
    html = "欢迎来到第一个页面"
    html += '<a href="http://www.163.com"> 网易 </a>'
    html += '<a href="/">返回首页</a>'
    return HttpResponse(html)

def index_view(request):
    html = "欢迎来到达内！"
    html += "跳转到第一页<a href='/page1'>第一页</a>"
    html += "跳转到第二页<a href='/page2'>第二页</a>"
    return HttpResponse(html)


def page2_view(request):
    html = "欢迎来到第二个页面"
    html += '<a href="/">返回首页</a>'
    return HttpResponse(html)


def year_view(request, y):
    html = "URL中的年份是：" + y
    return HttpResponse(html)


def cal_view(request, a, op, b):
    a = int(a)  # 转为整数
    b = int(b)
    if op == 'add':
        return HttpResponse(str(a+b))
    elif op == 'sub':
        return HttpResponse(str(a-b))
    elif op == 'mul':
        return HttpResponse(str(a*b))
    else:
        return HttpResponse('不能运算！！！')




def date_view(request, y, m, d):
    '''y, m, d绑定年月日'''
    html = y + '年' + m + '月' + d + '日'
    return HttpResponse(html)










