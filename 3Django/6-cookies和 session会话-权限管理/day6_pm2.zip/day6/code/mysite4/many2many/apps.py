from django.apps import AppConfig


class Many2ManyConfig(AppConfig):
    name = 'many2many'
