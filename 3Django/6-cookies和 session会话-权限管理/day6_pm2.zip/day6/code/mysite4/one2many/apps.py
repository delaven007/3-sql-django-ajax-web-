from django.apps import AppConfig


class One2ManyConfig(AppConfig):
    name = 'one2many'
