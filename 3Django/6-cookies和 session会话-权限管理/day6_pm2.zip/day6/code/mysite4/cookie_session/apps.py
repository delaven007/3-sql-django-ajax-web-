from django.apps import AppConfig


class CookieSessionConfig(AppConfig):
    name = 'cookie_session'
