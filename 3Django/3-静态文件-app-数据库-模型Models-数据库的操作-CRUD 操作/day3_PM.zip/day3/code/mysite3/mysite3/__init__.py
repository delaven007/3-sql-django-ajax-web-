

# file: mysite3/__init__.py

import pymysql

# 让Django 支持MySQL
pymysql.install_as_MySQLdb()