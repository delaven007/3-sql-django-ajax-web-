insert into sanguo(name,attack,defense,gender,country)
values
('司马懿',172,68,'M','魏国'),
('貂蝉',110,70,'F','吴国'),
('张飞',162,35,'M','蜀国'),
('赵云',199,99,'M','蜀国');